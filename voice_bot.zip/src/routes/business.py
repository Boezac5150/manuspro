from flask import Blueprint, request, jsonify, render_template_string
from src.models.business import Business, CallLog, db
import json

business_bp = Blueprint('business', __name__)

@business_bp.route('/', methods=['GET'])
def list_businesses():
    """List all businesses"""
    businesses = Business.query.all()
    return jsonify({
        'success': True,
        'businesses': [business.to_dict() for business in businesses]
    })

@business_bp.route('/', methods=['POST'])
def create_business():
    """Create a new business"""
    try:
        data = request.get_json()
        
        required_fields = ['name', 'phone_number']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'error': f'{field} is required'
                }), 400
        
        # Check if phone number already exists
        existing = Business.query.filter_by(phone_number=data['phone_number']).first()
        if existing:
            return jsonify({
                'success': False,
                'error': 'Phone number already registered'
            }), 400
        
        business = Business(
            name=data['name'],
            phone_number=data['phone_number'],
            services=data.get('services', []),
            hours=data.get('hours'),
            voice_id=data.get('voice_id'),
            greeting=data.get('greeting')
        )
        
        db.session.add(business)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'business': business.to_dict(),
            'message': 'Business created successfully'
        }), 201
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@business_bp.route('/<int:business_id>', methods=['GET'])
def get_business(business_id):
    """Get a specific business"""
    business = Business.query.get_or_404(business_id)
    return jsonify({
        'success': True,
        'business': business.to_dict()
    })

@business_bp.route('/<int:business_id>', methods=['PUT'])
def update_business(business_id):
    """Update a business"""
    try:
        business = Business.query.get_or_404(business_id)
        data = request.get_json()
        
        # Update fields if provided
        if 'name' in data:
            business.name = data['name']
        if 'phone_number' in data:
            # Check if new phone number already exists (excluding current business)
            existing = Business.query.filter(
                Business.phone_number == data['phone_number'],
                Business.id != business_id
            ).first()
            if existing:
                return jsonify({
                    'success': False,
                    'error': 'Phone number already registered'
                }), 400
            business.phone_number = data['phone_number']
        if 'services' in data:
            business.set_services(data['services'])
        if 'hours' in data:
            business.hours = data['hours']
        if 'voice_id' in data:
            business.voice_id = data['voice_id']
        if 'greeting' in data:
            business.greeting = data['greeting']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'business': business.to_dict(),
            'message': 'Business updated successfully'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@business_bp.route('/<int:business_id>', methods=['DELETE'])
def delete_business(business_id):
    """Delete a business"""
    try:
        business = Business.query.get_or_404(business_id)
        
        # Delete associated call logs first
        CallLog.query.filter_by(business_id=business_id).delete()
        
        db.session.delete(business)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Business deleted successfully'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@business_bp.route('/<int:business_id>/calls', methods=['GET'])
def get_business_calls(business_id):
    """Get call logs for a business"""
    business = Business.query.get_or_404(business_id)
    
    # Get pagination parameters
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    # Get call logs with pagination
    call_logs = CallLog.query.filter_by(business_id=business_id)\
                           .order_by(CallLog.created_at.desc())\
                           .paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'success': True,
        'business_name': business.name,
        'calls': [call.to_dict() for call in call_logs.items],
        'pagination': {
            'page': call_logs.page,
            'pages': call_logs.pages,
            'per_page': call_logs.per_page,
            'total': call_logs.total,
            'has_next': call_logs.has_next,
            'has_prev': call_logs.has_prev
        }
    })

@business_bp.route('/<int:business_id>/analytics', methods=['GET'])
def get_business_analytics(business_id):
    """Get analytics for a business"""
    business = Business.query.get_or_404(business_id)
    
    # Get all call logs for this business
    call_logs = CallLog.query.filter_by(business_id=business_id).all()
    
    # Calculate analytics
    total_calls = len(call_logs)
    total_duration = sum(call.call_duration or 0 for call in call_logs)
    avg_duration = total_duration / total_calls if total_calls > 0 else 0
    
    # Intent distribution
    intent_counts = {}
    outcome_counts = {}
    
    for call in call_logs:
        if call.intent:
            intent_counts[call.intent] = intent_counts.get(call.intent, 0) + 1
        if call.outcome:
            outcome_counts[call.outcome] = outcome_counts.get(call.outcome, 0) + 1
    
    # Recent calls (last 7 days)
    from datetime import datetime, timedelta
    seven_days_ago = datetime.now() - timedelta(days=7)
    recent_calls = [call for call in call_logs if call.created_at and call.created_at >= seven_days_ago]
    
    return jsonify({
        'success': True,
        'business_name': business.name,
        'analytics': {
            'total_calls': total_calls,
            'total_duration_seconds': total_duration,
            'average_duration_seconds': round(avg_duration, 2),
            'calls_last_7_days': len(recent_calls),
            'intent_distribution': intent_counts,
            'outcome_distribution': outcome_counts
        }
    })

@business_bp.route('/<int:business_id>/training', methods=['POST'])
def update_training_data(business_id):
    """Update training data for a business"""
    try:
        business = Business.query.get_or_404(business_id)
        data = request.get_json()
        
        # Update business information that affects AI training
        if 'services' in data:
            business.set_services(data['services'])
        if 'hours' in data:
            business.hours = data['hours']
        if 'greeting' in data:
            business.greeting = data['greeting']
        
        # You could extend this to include more sophisticated training data
        # like FAQ pairs, conversation flows, etc.
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Training data updated successfully',
            'business': business.to_dict()
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@business_bp.route('/phone/<phone_number>', methods=['GET'])
def get_business_by_phone(phone_number):
    """Get business configuration by phone number (used by voice bot)"""
    business = Business.query.filter_by(phone_number=phone_number).first()
    
    if not business:
        return jsonify({
            'success': False,
            'error': 'Business not found'
        }), 404
    
    return jsonify({
        'success': True,
        'business': business.to_dict()
    })
