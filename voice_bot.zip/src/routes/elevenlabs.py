from flask import Blueprint, request, jsonify, current_app
from elevenlabs import ElevenLabs, Voice, VoiceSettings
import os
import requests
from src.models.business import Business, db

elevenlabs_bp = Blueprint('elevenlabs', __name__)

# Initialize ElevenLabs client
def get_elevenlabs_client():
    api_key = os.getenv('ELEVENLABS_API_KEY')
    if not api_key:
        raise ValueError("ELEVENLABS_API_KEY environment variable not set")
    return ElevenLabs(api_key=api_key)

@elevenlabs_bp.route('/voices', methods=['GET'])
def list_voices():
    """List all available ElevenLabs voices"""
    try:
        client = get_elevenlabs_client()
        voices = client.voices.get_all()
        
        voice_list = []
        for voice in voices.voices:
            voice_list.append({
                'voice_id': voice.voice_id,
                'name': voice.name,
                'category': voice.category,
                'description': voice.description,
                'preview_url': voice.preview_url,
                'available_for_tiers': voice.available_for_tiers,
                'settings': {
                    'stability': voice.settings.stability if voice.settings else 0.5,
                    'similarity_boost': voice.settings.similarity_boost if voice.settings else 0.5,
                    'style': voice.settings.style if voice.settings else 0.0,
                    'use_speaker_boost': voice.settings.use_speaker_boost if voice.settings else True
                }
            })
        
        return jsonify({
            'success': True,
            'voices': voice_list,
            'count': len(voice_list)
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@elevenlabs_bp.route('/voices/<voice_id>/preview', methods=['GET'])
def preview_voice(voice_id):
    """Generate a preview of a specific voice"""
    try:
        client = get_elevenlabs_client()
        
        # Get sample text from query parameter or use default
        sample_text = request.args.get('text', 'Hello, this is a preview of my voice. How does it sound?')
        
        # Generate audio
        audio = client.generate(
            text=sample_text,
            voice=Voice(
                voice_id=voice_id,
                settings=VoiceSettings(
                    stability=0.5,
                    similarity_boost=0.5,
                    style=0.0,
                    use_speaker_boost=True
                )
            )
        )
        
        # Convert generator to bytes
        audio_bytes = b''.join(audio)
        
        return audio_bytes, 200, {
            'Content-Type': 'audio/mpeg',
            'Content-Disposition': f'attachment; filename="voice_preview_{voice_id}.mp3"'
        }
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@elevenlabs_bp.route('/voices/clone', methods=['POST'])
def clone_voice():
    """Clone a voice from uploaded audio files"""
    try:
        client = get_elevenlabs_client()
        
        # Get form data
        voice_name = request.form.get('name')
        voice_description = request.form.get('description', '')
        
        if not voice_name:
            return jsonify({
                'success': False,
                'error': 'Voice name is required'
            }), 400
        
        # Get uploaded files
        files = request.files.getlist('files')
        if not files or len(files) == 0:
            return jsonify({
                'success': False,
                'error': 'At least one audio file is required'
            }), 400
        
        # Prepare files for ElevenLabs API
        audio_files = []
        for file in files:
            if file.filename:
                audio_files.append(file.read())
        
        # Clone the voice
        voice = client.clone(
            name=voice_name,
            description=voice_description,
            files=audio_files
        )
        
        return jsonify({
            'success': True,
            'voice_id': voice.voice_id,
            'name': voice.name,
            'message': 'Voice cloned successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@elevenlabs_bp.route('/voices/<voice_id>/delete', methods=['DELETE'])
def delete_voice(voice_id):
    """Delete a cloned voice"""
    try:
        client = get_elevenlabs_client()
        
        # Delete the voice
        client.voices.delete(voice_id)
        
        return jsonify({
            'success': True,
            'message': 'Voice deleted successfully'
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@elevenlabs_bp.route('/generate', methods=['POST'])
def generate_speech():
    """Generate speech from text using specified voice"""
    try:
        client = get_elevenlabs_client()
        
        data = request.get_json()
        if not data:
            return jsonify({
                'success': False,
                'error': 'JSON data required'
            }), 400
        
        text = data.get('text')
        voice_id = data.get('voice_id')
        
        if not text or not voice_id:
            return jsonify({
                'success': False,
                'error': 'Both text and voice_id are required'
            }), 400
        
        # Get voice settings from request or use defaults
        settings = data.get('settings', {})
        voice_settings = VoiceSettings(
            stability=settings.get('stability', 0.5),
            similarity_boost=settings.get('similarity_boost', 0.5),
            style=settings.get('style', 0.0),
            use_speaker_boost=settings.get('use_speaker_boost', True)
        )
        
        # Generate audio
        audio = client.generate(
            text=text,
            voice=Voice(
                voice_id=voice_id,
                settings=voice_settings
            )
        )
        
        # Convert generator to bytes
        audio_bytes = b''.join(audio)
        
        return audio_bytes, 200, {
            'Content-Type': 'audio/mpeg',
            'Content-Disposition': 'attachment; filename="generated_speech.mp3"'
        }
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@elevenlabs_bp.route('/business/<int:business_id>/voice', methods=['POST'])
def set_business_voice(business_id):
    """Set the voice for a specific business"""
    try:
        business = Business.query.get_or_404(business_id)
        
        data = request.get_json()
        voice_id = data.get('voice_id')
        
        if not voice_id:
            return jsonify({
                'success': False,
                'error': 'voice_id is required'
            }), 400
        
        # Verify voice exists
        client = get_elevenlabs_client()
        try:
            voice = client.voices.get(voice_id)
        except:
            return jsonify({
                'success': False,
                'error': 'Invalid voice_id'
            }), 400
        
        # Update business voice
        business.voice_id = voice_id
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': f'Voice updated for {business.name}',
            'voice_id': voice_id
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@elevenlabs_bp.route('/usage', methods=['GET'])
def get_usage():
    """Get ElevenLabs API usage information"""
    try:
        client = get_elevenlabs_client()
        
        # Get user info which includes usage
        user = client.users.get()
        
        return jsonify({
            'success': True,
            'usage': {
                'character_count': user.subscription.character_count,
                'character_limit': user.subscription.character_limit,
                'can_extend_character_limit': user.subscription.can_extend_character_limit,
                'allowed_to_extend_character_limit': user.subscription.allowed_to_extend_character_limit,
                'next_character_count_reset_unix': user.subscription.next_character_count_reset_unix,
                'voice_limit': user.subscription.voice_limit,
                'max_voice_add_edits': user.subscription.max_voice_add_edits,
                'voice_add_edit_counter': user.subscription.voice_add_edit_counter,
                'professional_voice_limit': user.subscription.professional_voice_limit,
                'can_extend_voice_limit': user.subscription.can_extend_voice_limit,
                'can_use_instant_voice_cloning': user.subscription.can_use_instant_voice_cloning,
                'can_use_professional_voice_cloning': user.subscription.can_use_professional_voice_cloning,
                'tier': user.subscription.tier,
                'invoice_time_left': user.subscription.invoice_time_left,
                'status': user.subscription.status
            }
        })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500
