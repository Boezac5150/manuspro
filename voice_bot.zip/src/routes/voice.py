from flask import Blueprint, request, jsonify
from signalwire.rest import Client as SignalWireClient
from signalwire.voice_response import VoiceResponse, Gather
import os
import json
from openai import OpenAI
from elevenlabs import ElevenLabs
from deepgram import DeepgramClient, PrerecordedOptions, FileSource

voice_bp = Blueprint('voice', __name__)

# Initialize clients
openai_client = OpenAI()
elevenlabs_client = ElevenLabs(api_key=os.getenv('ELEVENLABS_API_KEY'))
deepgram_client = DeepgramClient(os.getenv('DEEPGRAM_API_KEY'))

# Business configuration - this would be loaded from database in production
BUSINESS_CONFIG = {
    "name": "SmileBright Dental",
    "services": ["cleaning", "consultation", "whitening", "emergency"],
    "hours": "Monday-Friday 9AM-5PM",
    "voice_id": "default",  # ElevenLabs voice ID
    "greeting": "Thank you for calling SmileBright Dental. How may I help you today?"
}

@voice_bp.route('/incoming-call', methods=['POST'])
def handle_incoming_call():
    """Handle incoming phone calls from SignalWire"""
    response = VoiceResponse()
    
    # Initial greeting
    response.say(BUSINESS_CONFIG["greeting"])
    
    # Gather user input
    gather = Gather(
        input='speech',
        action='/api/voice/process-speech',
        method='POST',
        speech_timeout='auto',
        language='en-US'
    )
    gather.say("Please tell me how I can assist you.")
    response.append(gather)
    
    # Fallback if no input
    response.say("I didn't hear anything. Please call back when you're ready to speak.")
    response.hangup()
    
    return str(response), 200, {'Content-Type': 'text/xml'}

@voice_bp.route('/process-speech', methods=['POST'])
def process_speech():
    """Process transcribed speech and generate AI response"""
    speech_result = request.form.get('SpeechResult', '')
    
    if not speech_result:
        response = VoiceResponse()
        response.say("I'm sorry, I didn't understand that. Could you please repeat?")
        response.redirect('/api/voice/incoming-call')
        return str(response), 200, {'Content-Type': 'text/xml'}
    
    # Process with AI
    ai_response = generate_ai_response(speech_result)
    
    # Generate voice response
    response = VoiceResponse()
    response.say(ai_response)
    
    # Continue conversation or end call based on intent
    if should_continue_conversation(ai_response):
        gather = Gather(
            input='speech',
            action='/api/voice/process-speech',
            method='POST',
            speech_timeout='auto',
            language='en-US'
        )
        gather.say("Is there anything else I can help you with?")
        response.append(gather)
    else:
        response.say("Thank you for calling. Have a great day!")
        response.hangup()
    
    return str(response), 200, {'Content-Type': 'text/xml'}

def generate_ai_response(user_input):
    """Generate AI response using OpenAI"""
    system_prompt = f"""
    You are a professional receptionist for {BUSINESS_CONFIG['name']}.
    
    Business Information:
    - Services: {', '.join(BUSINESS_CONFIG['services'])}
    - Hours: {BUSINESS_CONFIG['hours']}
    
    Your role is to:
    1. Help customers book appointments
    2. Answer questions about services
    3. Provide business information
    4. Be friendly, professional, and helpful
    
    Keep responses concise and natural for phone conversation.
    If someone wants to book an appointment, ask for their preferred date and time.
    """
    
    try:
        response = openai_client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_input}
            ],
            max_tokens=150,
            temperature=0.7
        )
        return response.choices[0].message.content
    except Exception as e:
        return "I apologize, but I'm having technical difficulties. Please try calling back in a few minutes."

def should_continue_conversation(response):
    """Determine if conversation should continue based on response"""
    end_phrases = [
        "thank you for calling",
        "have a great day",
        "goodbye",
        "appointment has been scheduled"
    ]
    return not any(phrase in response.lower() for phrase in end_phrases)

@voice_bp.route('/status', methods=['GET'])
def status():
    """Health check endpoint"""
    return jsonify({
        "status": "active",
        "business": BUSINESS_CONFIG["name"],
        "services": BUSINESS_CONFIG["services"]
    })

@voice_bp.route('/configure', methods=['POST'])
def configure_business():
    """Configure business settings"""
    global BUSINESS_CONFIG
    
    data = request.get_json()
    if data:
        BUSINESS_CONFIG.update(data)
        return jsonify({"message": "Configuration updated successfully"})
    
    return jsonify({"error": "Invalid configuration data"}), 400
