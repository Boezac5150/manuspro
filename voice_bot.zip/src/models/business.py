from flask_sqlalchemy import SQLAlchemy
from src.models.user import db
import json

class Business(db.Model):
    __tablename__ = 'businesses'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    phone_number = db.Column(db.String(20), unique=True, nullable=False)
    services = db.Column(db.Text)  # JSON string of services
    hours = db.Column(db.String(200))
    voice_id = db.Column(db.String(100))  # ElevenLabs voice ID
    greeting = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())
    
    def __init__(self, name, phone_number, services=None, hours=None, voice_id=None, greeting=None):
        self.name = name
        self.phone_number = phone_number
        self.services = json.dumps(services) if services else json.dumps([])
        self.hours = hours or "Monday-Friday 9AM-5PM"
        self.voice_id = voice_id or "default"
        self.greeting = greeting or f"Thank you for calling {name}. How may I help you today?"
    
    def get_services(self):
        """Return services as a Python list"""
        return json.loads(self.services) if self.services else []
    
    def set_services(self, services_list):
        """Set services from a Python list"""
        self.services = json.dumps(services_list)
    
    def to_dict(self):
        """Convert business to dictionary"""
        return {
            'id': self.id,
            'name': self.name,
            'phone_number': self.phone_number,
            'services': self.get_services(),
            'hours': self.hours,
            'voice_id': self.voice_id,
            'greeting': self.greeting,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class CallLog(db.Model):
    __tablename__ = 'call_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    business_id = db.Column(db.Integer, db.ForeignKey('businesses.id'), nullable=False)
    caller_number = db.Column(db.String(20))
    call_duration = db.Column(db.Integer)  # in seconds
    transcript = db.Column(db.Text)
    intent = db.Column(db.String(100))  # appointment, inquiry, etc.
    outcome = db.Column(db.String(100))  # scheduled, information_provided, etc.
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    
    business = db.relationship('Business', backref=db.backref('call_logs', lazy=True))
    
    def __init__(self, business_id, caller_number=None, call_duration=0, transcript=None, intent=None, outcome=None):
        self.business_id = business_id
        self.caller_number = caller_number
        self.call_duration = call_duration
        self.transcript = transcript
        self.intent = intent
        self.outcome = outcome
    
    def to_dict(self):
        """Convert call log to dictionary"""
        return {
            'id': self.id,
            'business_id': self.business_id,
            'caller_number': self.caller_number,
            'call_duration': self.call_duration,
            'transcript': self.transcript,
            'intent': self.intent,
            'outcome': self.outcome,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
